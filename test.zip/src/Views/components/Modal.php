<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center">
                Are you sure you want to delete all contacts?
            </div>
            <div class="my-3 d-flex justify-content-center">
                <a href="/delete_all" class="btn btn-danger me-2">Yes</a>
                <button type="button" class="btn btn-primary ms-2" data-bs-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>